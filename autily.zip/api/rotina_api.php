<?php 

session_start(); // Inicia a sessão
include('../config_serv/conexao.php'); // Conexão com o banco
ini_set('display_errors', 1); // Habilitar exibição de erros para depuração
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); // Exibe todos os erros

// Verificação de sessão para garantir que o usuário está logado
if (!isset($_SESSION['id'])) {
    // Redireciona o usuário para a página de login caso não esteja logado
    header("Location: ../api/erro404.php");
    exit();
}

// Obter os dados do formulário quando o método for POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Receber os dados do formulário
    $data = $_POST['data'];  // Data
    $horario = $_POST['horario'];  // Horário
    $desc = $_POST['desc'];  // Comentário
    $id_resp = $_SESSION['id'];  // ID do responsável (usuário logado)

    // Validar os dados recebidos
    if (empty($data) || empty($horario) || empty($desc)) {
        die("Todos os campos são obrigatórios.");
    }

    // Verificar se o ID do responsável (usuário logado) existe na tabela 'usuarios'
    $sql_check_user = "SELECT id FROM usuarios WHERE id = ?";
    if ($stmt_check = $conn->prepare($sql_check_user)) {
        $stmt_check->bind_param('i', $id_resp);
        $stmt_check->execute();
        $stmt_check->store_result();
        
        // Se o ID do usuário não existir, retornar erro
        if ($stmt_check->num_rows == 0) {
            die("Usuário não encontrado na tabela 'usuarios'.");
        }
        $stmt_check->close();
    }

    // Preparar a consulta SQL para inserir os dados na tabela 'rotina'
    $sql = "INSERT INTO rotina (data, horario, tarefa, id_resp) VALUES (?, ?, ?, ?)";

    // Usar prepared statement para evitar SQL injection
    if ($stmt = $conn->prepare($sql)) {
        // Vincular os parâmetros para a consulta
        $stmt->bind_param('sssi', $data, $horario, $desc, $id_resp);

        // Executar a consulta
        if ($stmt->execute()) {
            echo "Rotina adicionada com sucesso!";
            header("Location: ../php/rotinaP.php");
            exit();
        } else {
            echo "Erro ao adicionar rotina: " . $stmt->error;
        }

        // Fechar a declaração
        $stmt->close();
    } else {
        echo "Erro na preparação da consulta: " . $conn->error;
    }
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
