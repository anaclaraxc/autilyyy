<?php
session_start();
include('../config_serv/conexao.php');

// Verificação de sessão para garantir que o usuário está logado
if (!isset($_SESSION['id'])) {
    echo json_encode(['error' => 'Usuário não logado']);
    exit();
}

// Obter o id do usuário logado
$id_resp = $_SESSION['id'];

// Consulta para pegar todas as rotinas do usuário
$sql = "SELECT data, horario, tarefa FROM rotina WHERE id_resp = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('i', $id_resp);
    $stmt->execute();
    $stmt->store_result();
    
    $stmt->bind_result($data, $horario, $tarefa);

    // Preparar o array de resultados
    $rotinas = [];
    while ($stmt->fetch()) {
        $rotinas[] = [
            'data' => $data,
            'horario' => $horario,
            'tarefa' => $tarefa
        ];
    }

    // Retornar os resultados como JSON
    echo json_encode($rotinas);

    $stmt->close();
} else {
    echo json_encode(['error' => 'Erro na consulta ao banco']);
}

$conn->close();