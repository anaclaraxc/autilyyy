<?php
session_start();
include('../config_serv/conexao.php'); // Conexão com o banco

// Verificação de sessão para garantir que o usuário está logado
if (!isset($_SESSION['id'])) {
    // Redireciona o usuário para a página de login caso não esteja logado
    header("Location: ../api/erro404.php");
    exit();
}

// Verificar se o ID da rotina foi passado via GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];  // Receber o ID da rotina a ser deletada

    // Validar se o ID é numérico
    if (!is_numeric($id)) {
        die("ID inválido.");
    }

    // Verificar se a rotina pertence ao usuário logado
    $id_resp = $_SESSION['id'];  // ID do usuário logado

    // Preparar a consulta SQL para verificar se a rotina existe para o usuário logado
    $sql_check = "SELECT id FROM rotina WHERE id = ? AND id_resp = ?";
    if ($stmt = $conn->prepare($sql_check)) {
        $stmt->bind_param('ii', $id, $id_resp);
        $stmt->execute();
        $stmt->store_result();

        // Se a rotina não for encontrada para o usuário, exibir erro
        if ($stmt->num_rows === 0) {
            die("Rotina não encontrada ou você não tem permissão para excluí-la.");
        }
        $stmt->close();
    } else {
        die("Erro na consulta de verificação.");
    }

    // Preparar a consulta SQL para excluir a rotina
    $sql_delete = "DELETE FROM rotina WHERE id = ? AND id_resp = ?";
    if ($stmt = $conn->prepare($sql_delete)) {
        // Vincular os parâmetros para a consulta
        $stmt->bind_param('ii', $id, $id_resp);

        // Executar a consulta
        if ($stmt->execute()) {
            // Verificar se a rotina foi excluída
            if ($stmt->affected_rows > 0) {
                // Excluído com sucesso, mas não redireciona
                header("Location: ../php/rotinaP.php");  // Atualiza a página para refletir a exclusão
                exit();
            } else {
                die("Erro ao excluir rotina.");
            }
        } else {
            die("Erro na execução da consulta de exclusão.");
        }

        $stmt->close();
    } else {
        die("Erro na preparação da consulta de exclusão.");
    }

    // Fechar a conexão com o banco de dados
    $conn->close();
} else {
    die("ID da rotina não fornecido.");
}
?>
