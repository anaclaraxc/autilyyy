<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start(); // Inicia a sessão no topo

include_once('../config_serv/conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);

    $email = $conn->real_escape_string($email);
    $senha = $conn->real_escape_string($senha);

    $queryUsuarios = "SELECT * FROM usuarios WHERE email = '$email'";
    $resultUsuarios = $conn->query($queryUsuarios);

    if ($resultUsuarios->num_rows > 0) {
        $usuario = $resultUsuarios->fetch_assoc();

        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['email'] = $usuario['email'];
            $_SESSION['tipo_usuario'] = 'pais';

            header('Location: ../php/pais.php');
            exit();
        } else {
            echo "Senha incorreta.";
        }
    } else {
        $queryCrianca = "SELECT * FROM crianca WHERE email = '$email'";
        $resultCrianca = $conn->query($queryCrianca);

        if ($resultCrianca->num_rows > 0) {
            $crianca = $resultCrianca->fetch_assoc();

            if (password_verify($senha, $crianca['senha'])) {
                $_SESSION['id_crianca'] = $crianca['id_crianca'];
                $_SESSION['nome'] = $crianca['nome'];
                $_SESSION['email'] = $crianca['email'];
                $_SESSION['tipo_usuario'] = 'crianca';

                header('Location: ../php/crianca.php');
                exit();
            } else {
                echo "Senha incorreta.";
            }
        } else {
            echo "Usuário não encontrado.";
        }
    }
}
?>