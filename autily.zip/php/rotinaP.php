<?php
session_start();
include('../config_serv/conexao.php'); // Conexão com o banco

// Verificação de sessão para garantir que o usuário está logado
if (!isset($_SESSION['id'])) {
    header("Location: ../api/erro404.php");
    exit();
}

// Buscar as rotinas do usuário logado no banco de dados
$id_resp = $_SESSION['id'];  // ID do responsável (usuário logado)
$sql = "SELECT * FROM rotina WHERE id_resp = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_resp);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Rotina - Pais</title>
    <style>
        /* Estilos globais */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(45deg, #ffffff, #ffffff, #ffffff);
            background-size: 300% 300%;
            animation: backgroundAnimation 10s ease infinite;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 150vh;
            margin: 0;
            padding: 10px; /* Espaço adicional para não grudar na borda */
        }

        .background-bubbles {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
            overflow: hidden;
        }

        .bubble {
            position: absolute;
            border-radius: 50%;
            opacity: 0.5;
            background-color: #66B9FA;
            animation: rise 15s infinite linear;
        }

        @keyframes rise {
            0% {
                transform: translateY(100vh);
            }

            100% {
                transform: translateY(-100vh);
            }
        }

        .bubble:nth-child(1) {
            width: 100px;
            height: 100px;
            left: 10%;
            animation-duration: 7s;
        }

        .bubble:nth-child(2) {
            width: 150px;
            height: 150px;
            left: 70%;
            animation-duration: 12s;
        }

        .bubble:nth-child(3) {
            width: 50px;
            height: 50px;
            left: 30%;
            animation-duration: 10s;
        }

        .bubble:nth-child(4) {
            width: 80px;
            height: 80px;
            left: 50%;
            animation-duration: 15s;
        }

        .bubble:nth-child(5) {
            width: 60px;
            height: 60px;
            left: 20%;
            animation-duration: 8s;
        }

        .bubble:nth-child(6) {
            width: 120px;
            height: 120px;
            left: 80%;
            animation-duration: 18s;
        }

        .bubble:nth-child(7) {
            width: 90px;
            height: 90px;
            left: 40%;
            animation-duration: 20s;
        }

        .bubble:nth-child(8) {
            width: 110px;
            height: 110px;
            left: 60%;
            animation-duration: 14s;
        }

        .bubble:nth-child(9) {
            width: 130px;
            height: 130px;
            left: 15%;
            animation-duration: 22s;
        }

        .bubble:nth-child(10) {
            width: 70px;
            height: 70px;
            left: 75%;
            animation-duration: 9s;
        }

        .container {
            text-align: center;
            max-width: 900px;
            width: 100%;
            padding: 20px;
            border-radius: 10px;
            background-color: rgba(0 132 255 / 60%);
            box-shadow: 0 4px 10px rgba(71, 139, 202, 0.6);
            margin: 0 auto;
        }

        h1 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .tabela {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .tabela th,
        .tabela td {
            padding: 12px;
            text-align: center;
            font-size: 1.1em;
        }

        .tabela th {
            background-color: #1E90FF;
            color: white;
            border: 1px solid #ddd;
        }

        .tabela td {
            background-color: #ADD8E6;
            border: 1px solid #ddd;
        }

        .tabela input,
        .tabela textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: none;
            background-color: #e8f0fe;
            font-size: 1em;
        }

        textarea {
            height: 60px;
        }

        button {
            background-color: #1E90FF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.2em;
            margin-top: 20px;
            width: 100%;
            max-width: 300px;
            margin-left: auto;
            margin-right: auto;
        }

        button:hover {
            background-color: blue;
        }

        h2 {
            margin-top: 30px;
            margin-bottom: 20px;
        }

        .tabela {
            margin-bottom: 30px;
        }

        .delete-btn {
            color: white;
            font-size: 1.2em;
            background-color: blue;
            padding: 5px;
            border-radius: 5px;
            text-decoration: none;
        }

        .delete-btn:hover {
            background-color: red;
        }

    </style>
</head>

<body>
    <div class="scrollable-app">
        <main class="main-content">
            <div class="background-bubbles">
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
            </div>

            <div class="container">
                <h1>Adicionar Rotina</h1>
                <form action="../api/rotina_api.php" method="POST">
                    <table class="tabela" id="tabela-rotinas">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Horário</th>
                                <th>Comentário</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="date" name="data" required></td>
                                <td><input type="time" name="horario" required></td>
                                <td><input type="text" name="desc" placeholder="Descreva a tarefa" required></td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Botão para adicionar linha com ícone do Font Awesome 
                    //<button type="button" onclick="adicionarLinha()">
                        <i class="fas fa-plus"></i> Adicionar
                    </button-->

                    <!-- Botão para salvar com ícone de check -->
                    <button type="submit">
                        <i class="fas fa-check"></i> Salvar
                    </button>
                </form>

              <h2>Minhas Rotinas</h2>
<table class="tabela" id="rotinas-exibidas">
    <thead>
        <tr>
            <th>Data</th>
            <th>Horário</th>
            <th>Tarefa</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Exibindo as rotinas
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['data']) . "</td>"; // Exibe o campo 'data'
            echo "<td>" . htmlspecialchars($row['horario']) . "</td>"; // Exibe o campo 'horario'
            echo "<td>" . htmlspecialchars($row['tarefa']) . "</td>"; // Exibe o campo 'tarefa'
            echo "<td><a href='../api/rotina_delete.php?id={$row['id']}' class='delete-btn'><i class='fas fa-trash-alt'></i></a></td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>
                <button class="btn-voltar" onclick="window.history.back()">Voltar</button>
            </div>
        </main>
    </div>
    
    <script>
    function excluirRotina(id) {
    // Confirmação de exclusão
    if (confirm('Tem certeza que deseja excluir esta rotina?')) {
        // Criar requisição AJAX
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '../api/rotina_delete.php?id=' + id, true);

        // Quando a requisição for completada
        xhr.onload = function() {
            if (xhr.status === 200) {
                // Verificar se a resposta foi bem-sucedida
                if (xhr.responseText.indexOf("Rotina não encontrada") === -1) {
                    // Se a exclusão foi bem-sucedida, removemos a linha da tabela
                    var row = document.getElementById('linha-' + id);
                    row.remove();
                } else {
                    alert('Erro ao excluir a rotina!');
                }
            } else {
                alert('Erro na comunicação com o servidor!');
            }
        };

        // Enviar o ID da rotina para o PHP (sem redirecionar a página)
        xhr.send();
    }
}
    </script>
</body>
</html>
