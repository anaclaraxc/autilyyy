<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config_serv/conexao.php';

// Verifica se o ID da criança está na sessão
if (!isset($_SESSION['id_crianca'])) {
    die("Erro: Nenhuma criança logada.");
}

$id_crianca = $_SESSION['id_crianca'];

// Consulta para buscar as rotinas relacionadas à criança logada
$sql_rotinas = "
    SELECT r.data, r.horario, r.tarefa
    FROM rotina r
    JOIN crianca c ON c.responsavel_id = r.id_resp
    WHERE c.id_crianca = ?
";

$stmt_rotinas = $conn->prepare($sql_rotinas);
if (!$stmt_rotinas) {
    die("Erro na preparação da consulta: " . $conn->error);
}

$stmt_rotinas->bind_param('i', $id_crianca);
$stmt_rotinas->execute();
$result_rotinas = $stmt_rotinas->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotina - Criança</title>
    <style>
        /* Estilos gerais do corpo */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
           
            height: 100vh;
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        
     .background-bubbles {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: -1;
    overflow: hidden;
}

.bubble {
    position: absolute;
    border-radius: 50%;
    opacity: 0.5;
    background-color: #66B9FA;
    animation: rise 15s infinite linear; 
}

@keyframes rise {
    0% {
        transform: translateY(100vh); 
    }
    100% {
        transform: translateY(-100vh); 
    }
}

.bubble:nth-child(1) { width: 100px; height: 100px; left: 10%; animation-duration: 7s; }
.bubble:nth-child(2) { width: 150px; height: 150px; left: 70%; animation-duration: 12s; }
.bubble:nth-child(3) { width: 50px; height: 50px; left: 30%; animation-duration: 10s; }
.bubble:nth-child(4) { width: 80px; height: 80px; left: 50%; animation-duration: 15s; }
.bubble:nth-child(5) { width: 60px; height: 60px; left: 20%; animation-duration: 8s; }
.bubble:nth-child(6) { width: 120px; height: 120px; left: 80%; animation-duration: 18s; }
.bubble:nth-child(7) { width: 90px; height: 90px; left: 40%; animation-duration: 20s; }
.bubble:nth-child(8) { width: 110px; height: 110px; left: 60%; animation-duration: 14s; }
.bubble:nth-child(9) { width: 130px; height: 130px; left: 15%; animation-duration: 22s; }
.bubble:nth-child(10) { width: 70px; height: 70px; left: 75%; animation-duration: 9s; }


        /* Contêiner principal */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: blue;
            text-align: center;
        }

        /* Título */
        h1 {
            color: #007bff;
            font-size: 28px;
            margin-bottom: 20px;
        }

        /* Estilo da tabela */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            table-layout: fixed;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
            word-wrap: break-word;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        td {
            background-color: #f9f9f9;
        }

        /* Estilo do botão */
        button {
            background-color: #007bff;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Estilos responsivos */
        @media (max-width: 768px) {
            table {
                font-size: 14px;
                border: 0;
                width: 100%;
               
                overflow-x: auto;
            }

            th, td {
                padding: 8px;
            }

            .container {
                width: 80%;
            }

            h1 {
                font-size: 24px;
            }
        }

        .imagem-personagem {
            width: 100%;
            max-width: 250px;
            display: block;
            margin: 30px auto;
            border-radius: 10px;
            animation: flutuar 3s ease-in-out infinite;
        }

        @keyframes flutuar {
            0% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
            100% { transform: translateY(0); }
        }
    </style>
</head>

<body>
        <div class="scrollable-app">
        <main class="main-content">
            <div class="background-bubbles">
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
            </div>

    <div class="container">
        <h1>Tabela de Rotina</h1>

        <!-- Tabela de rotina -->
        <table id="tabela-rotina">
            <thead>
                <tr>
                    <th>Horário</th>
                    <th>Data</th>
                    <th>Comentário</th>
                </tr>
            </thead>
               <tbody>
                        <?php if ($result_rotinas->num_rows > 0): ?>
                            <?php while ($rotina = $result_rotinas->fetch_assoc()): ?>
                                <tr>
                                    <td><?php
                                        $horario_obj = new DateTime($rotina['horario']);
                                        echo $horario_obj->format('H:i'); //hora e minuto
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $data_obj = new DateTime($rotina['data']);
                                        echo $data_obj->format('d/m/Y'); // dd/mm/yyyy
                                        ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($rotina['tarefa']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">Nenhuma rotina encontrada.</td>
                            </tr>
                        <?php endif; ?>
            </tbody>
        </table>

        <!-- Botão de Voltar -->
        <div style="text-align: center; margin-top: 20px;">
            <button onclick="window.history.back();">Voltar</button>
        </div>
    </div>

    <!-- Imagem do personagem abaixo da tabela -->
    <img src="mia_animada.png" alt="Personagem" class="imagem-personagem">

</body>

</html>