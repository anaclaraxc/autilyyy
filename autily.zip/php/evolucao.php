<?php
session_start(); // Inicia a sessão

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica se o usuário está logado
if (!isset($_SESSION['id'])) {
    header("Location: ../api/erro404.php"); // Redireciona para a página de erro ou login
    exit();
}

include('../config_serv/conexao.php'); // Inclui a conexão com o banco de dados (conexao.php)

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../chatbot/style.css">
    <title>Evolução da Criança</title>
    <style>
        /* Estilos principais */
        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            color: #00a2ff;
            overflow-x: hidden;
        }

        header {
            background-color: #66B9FA;
            padding: 10px;
            position: relative;
        }

        .logo {
            height: 40px;
            margin-left: 47%;
        }

        .scrollable-app {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .main-content {
            flex: 1;
            padding-bottom: 30px;
        }

        .unit {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center;
            background-color: #e6e6e6;
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 350px;
            margin-top: 10%;
        }

        .unit-info h3,
        .unit-info p {
            color: #000;
        }

        .progress-bar-container {
            width: 100%;
            height: 20px;
            background-color: #e6e6e6;
            border-radius: 10px;
        }

        .progress-bar {
            height: 100%;
            background-color: #00a2ff;
            border-radius: 10px;
        }

        footer {
            background-color: #66B9FA;
            color: #fff;
            text-align: center;
            padding: 20px;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        footer p {
            margin: 5px 0;
        }

        footer a {
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <header>
        <a href="pais.php">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
        <img src="../img/autily azul claro.png" alt="Logo" class="logo">
    </header>

    <div class="scrollable-app">
        <main class="main-content">
            <div class="background-bubbles">
                <!-- Animações de bolhas no fundo -->
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
                <div class="bubble"></div>
            </div>

            <?php
            // Consultar as pontuações da criança usando mysqli
            $id_crianca = $_SESSION['id']; // ID da criança vindo da sessão

            // Consulta as pontuações da criança no banco
            $sql = "SELECT j.nome_jogo, p.pontuacao, j.pontos_maximos
                    FROM pontuacoes p
                    JOIN jogos j ON p.id_jogo = j.id_jogo
                    WHERE p.id_crianca = ?";
            
            // Preparar a consulta
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $id_crianca); // "i" significa que estamos passando um inteiro
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            // Verifica se há pontuações e exibe
            if (mysqli_num_rows($result) > 0) {
                echo '<div id="gameCardsContainer">';
                while ($pontuacao = mysqli_fetch_assoc($result)) {
                    echo '<div class="unit">';
                    echo '<div class="unit-info">';
                    echo '<h3>' . $pontuacao['nome_jogo'] . '</h3>';
                    echo '<h4>Pontuação:</h4>';
                    echo '<p>' . $pontuacao['pontuacao'] . '/' . $pontuacao['pontos_maximos'] . '</p>'; // Agora mostra a pontuação máxima de cada jogo
                    echo '<h3>Evolução Atual:</h3>';
                    echo '</div>';
                    echo '<div class="progress-bar-container">';
                    echo '<div class="progress-bar" style="width: ' . (($pontuacao['pontuacao'] / $pontuacao['pontos_maximos']) * 100) . '%"></div>';
                    echo '</div>';
                    echo '</div>';
                }
                echo '</div>';
            } else {
                echo '<p>Não há pontuações disponíveis para essa criança.</p>';
            }

            // Fechar a conexão
            mysqli_close($conn);
            ?>

        </main>

        <footer>
            <p>&copy; 2024 Autily</p>
            <p>Desenvolvido por: Equipe Autily</p>
            <p>Contato: <a href="mailto:autilyy@gmail.com">autilyy@gmail.com</a></p>
        </footer>
    </div>
</body>

</html>
