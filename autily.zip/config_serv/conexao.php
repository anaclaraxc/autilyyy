<?php
$servidor = "localhost";  // O servidor que está rodando seu MySQL
$usuario = "u301136860_autily";        // Usuário padrão do MySQL
$senha = "Autilytcc2024";              // Senha do MySQL
$dbname = "u301136860_autily";       // Nome do banco de dados

// Criar a conexão
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

// Verificar a conexão
if (!$conn) {
    die("Falha na conexão: " . mysqli_connect_error());
}
?>
